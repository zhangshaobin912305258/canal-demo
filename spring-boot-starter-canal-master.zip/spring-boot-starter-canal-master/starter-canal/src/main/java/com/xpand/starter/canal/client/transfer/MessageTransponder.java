package com.xpand.starter.canal.client.transfer;

/**
 * Interface that used to transfer the message from the canal server
 *
 * @author chen.qian
 * @date 2018/3/19
 */
public interface MessageTransponder extends Runnable {
}
